
/* JavaScript content from js/messages_ru.js in folder common */
(function () {
	Messages.search_searchBar = "Поиск";
	Messages.search_welcome = "Вы можете ввести в поле Поиск имя, фамилилию, почтовый адрес или любую другую информацию для поиска";
}());
